package assalaam.studio.ujikom.app;

public class AppConfig {
	// Server user login url
	public static String URL_LOGIN = "http://ujikom-2017.smkassalaambandung.sch.id/api/login";

	// Server user register url
	public static String URL_REGISTER = "http://ujikom-2017.smkassalaambandung.sch.id/api/register";
}
